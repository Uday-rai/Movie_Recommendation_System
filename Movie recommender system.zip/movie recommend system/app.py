import streamlit as st
import pandas as pd
import joblib

def recommend(movie):
    movie_index = movies[movies['title'] == movie].index[0]
    distances = similarity[movie_index]
    movies_list = sorted(list(enumerate(distances)),reverse=True,key=lambda x:x[1])[1:6]
    recomended_movies = []
    for i in movies_list:
        recomended_movies.append(movies.iloc[i[0]].title)
    return recomended_movies
similarity = joblib.load('similarity.pkl')

movies_dict = joblib.load('movies_dict.pkl')
movies =pd.DataFrame(movies_dict)

st.title('Movie Recommendation System')




selected_movie_name = st.selectbox(('search a movie you like'), movies['title'].values)
if st.button('Recommend'):
    recommentations = recommend(selected_movie_name)
    for i in recommentations:
        st.write(i)
